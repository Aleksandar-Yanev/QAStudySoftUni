﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManufacturer
{
    public class Tire
    {
        public int Year {  get; set; }
        public double Presure { get; set; }

        public Tire(int year, double presure) 
        {
            this.Year = year;
            this.Presure = presure;
        }
    }
}
